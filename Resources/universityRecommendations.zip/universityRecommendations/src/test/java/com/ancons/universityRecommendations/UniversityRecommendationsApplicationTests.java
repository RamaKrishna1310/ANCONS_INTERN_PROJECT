package com.ancons.universityRecommendations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversityRecommendationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
